#include "EnemyCar.h"

int EnemyCar::maxSpeed=3;
int EnemyCar::minSpeed=1;
SDL_Texture* EnemyCar::enemyCarTextures=nullptr;

EnemyCar::EnemyCar()
{
    //ctor
    SDL_Rect sources[7];
    sources[0]={410,270,475-410,400-270};
    sources[1]={475,270,475-410,400-270};
    sources[2]={540,270,475-410,400-270};
    sources[3]={370,0,460-370,230};
    sources[4]={470,0,530-470,160};
    sources[5]={540,0,600-540,160};
    sources[6]={610,0,680-610,160};

    enemyCarTextures=Game::loadTexture("assets/images/carSprites.png",255,255,255);

    int t=rand()%(6+1) + 0;
    int xpos=rand()%(3)+1;
    if(xpos==1)  xpos=120;
    else if(xpos==2)  xpos=180;
    else if(xpos==3)  xpos=240;
    else xpos=120;
    carSpeed=rand()%(maxSpeed-minSpeed+1)+minSpeed;

    srcRect=sources[t];
    destRect.x=xpos;   destRect.w=25;
    if(t<=2)
        destRect.h=50;
    else if(t==3)
        destRect.h=80;
    else
        destRect.h=60;
    destRect.y=Game::gameBoundry.y-destRect.h;
}

EnemyCar::~EnemyCar()
{
    //dtor
    SDL_DestroyTexture(enemyCarTextures);  enemyCarTextures=nullptr;

}

bool EnemyCar::updateEnemyCar()
{
    destRect.y+=carSpeed;
    if(destRect.y>=Game::gameBoundry.y+Game::gameBoundry.h)
        return false;
    else
    {
        drawEnemyCar();
        return true;
    }
}
void EnemyCar::drawEnemyCar()
{
    SDL_RenderCopy(Game::gameRenderer,enemyCarTextures,&srcRect,&destRect);
}

