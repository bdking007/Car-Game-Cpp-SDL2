#include "Car.h"

Car::Car()
{
    //ctor
    carTexture=nullptr;

    carPos={120,500,30,50};  xSpeed=ySpeed=0;   velocity=2;

    carBounds={110,Game::gameBoundry.y,175,Game::gameBoundry.h};
}

Car::~Car()
{
    //dtor
    SDL_DestroyTexture(carTexture);  carTexture=nullptr;
}

bool Car::loadCar(string path)
{
    carTexture=Game::loadTexture(path.c_str(),255,255,255);
    if(!carTexture)
        return false;
    else
        return true;
}

void Car::moveCar(int dir)
{
    if(dir==LEFT)
    {
        xSpeed=-velocity;
    }
    else if(dir==RIGHT)
    {
        xSpeed=velocity;
    }
    else if(dir==UP)
    {
        ySpeed=-velocity;

    }
    else if(dir==DOWN)
    {
        ySpeed=+velocity;
    }

}
void Car::drawCar()
{
    SDL_Rect carSrcRect={350,270,410-350,405-270};

    carPos.x+=xSpeed;
    if(carPos.x<carBounds.x)
        carPos.x=carBounds.x;
    else if(carPos.x+carPos.w>carBounds.x+carBounds.w)
        carPos.x=carBounds.x+carBounds.w-carPos.w;

    carPos.y+=ySpeed;
    if(carPos.y<carBounds.y)
        carPos.y=carBounds.y;
    else if(carPos.y+carPos.h>carBounds.y+carBounds.h)
        carPos.y=carBounds.y+carBounds.h-carPos.h;

    SDL_RenderCopy(Game::gameRenderer,carTexture,&carSrcRect,&carPos);
}

void Car::handleCarEvents(const SDL_Event& evnt)
{
    if(evnt.type==SDL_KEYDOWN && evnt.key.repeat==0)
    {
        switch(evnt.key.keysym.sym)
        {
        case SDLK_LEFT :
            moveCar(LEFT);
            break;
        case SDLK_RIGHT :
            moveCar(RIGHT);
            break;
        case SDLK_UP:
            moveCar(UP);
            break;
        case SDLK_DOWN:
            moveCar(DOWN);
            break;
        }
    }

    if(evnt.type==SDL_KEYUP && evnt.key.repeat==0)
    {
        switch(evnt.key.keysym.sym)
        {
        case SDLK_LEFT :
            xSpeed=0;
            break;
        case SDLK_RIGHT:
            xSpeed=0;
            break;
        case SDLK_UP:
            ySpeed=0;
            break;
        case SDLK_DOWN:
            ySpeed=0;
            break;
        }
    }
}
