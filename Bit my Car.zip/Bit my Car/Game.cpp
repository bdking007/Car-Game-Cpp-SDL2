#include "Game.h"

Car ourCar;
gameBackground background;
EnemyCar* enmCars[100];
int currentEnmCars;


Game::Game()
{
    //ctor
    gameSurface=nullptr;   gameWindow=nullptr;  gameOverTexture=nullptr;
    bgm=nullptr;   gameOverEffect=nullptr;   outEffect=nullptr;
    gameOn=false;   playStart=false;

    for(int i=0;i<100;i++)
        enmCars[i]=nullptr;

    srand(time(NULL));   score=0;
    currentEnmCars=3;
}

Game::~Game()
{
    //dtor
    gameSurface=nullptr;    gameRenderer=nullptr;
    gameWindow=nullptr;   font=nullptr;   gameOverTexture=nullptr;
    bgm=nullptr;   gameOverEffect=nullptr;  outEffect=nullptr;
}

SDL_Renderer *Game::gameRenderer=nullptr;
TTF_Font *Game::font=nullptr;
SDL_Rect Game::gameBoundry={0,0,SCREEN_WIDTH,SCREEN_HEIGHT};

void Game::fatalError(string error,bool closeProgram)
{
    cout<<"Error Occured : "<<error<<endl;
    if(closeProgram)
    {
        Game g;
        g.cleanSystem();
        cin.get();
        exit(-1);
    }
}

bool Game::checkCollision(SDL_Rect a,SDL_Rect b)
{
    if(a.x+a.w<b.x)
        return false;
    else if(a.y+a.h<b.y)
        return false;
    else if(b.x+b.w<a.x)
        return false;
    else if(b.y+b.h<a.y)
        return false;
    else
        return true;
}

SDL_Texture* Game::loadTexture(string path,int r,int g,int b)
{
    SDL_Surface *tempImgSurface=IMG_Load(path.c_str());
    SDL_Texture *retTexture=nullptr;
    if(tempImgSurface==nullptr)
    {
        cout<<"Image not found : "<<path<<endl;
    }
    else
    {
        SDL_SetColorKey(tempImgSurface,SDL_TRUE,SDL_MapRGB(tempImgSurface->format,r,g,b));
        retTexture=SDL_CreateTextureFromSurface(gameRenderer,tempImgSurface);
        SDL_FreeSurface(tempImgSurface);   tempImgSurface=nullptr;
    }
    return retTexture;
}

SDL_Texture* Game::loadText(string text,SDL_Color color)
{
    SDL_Surface *textSurface=TTF_RenderText_Solid(Game::font,text.c_str(),color);
    SDL_Texture *ret=SDL_CreateTextureFromSurface(gameRenderer,textSurface);
    SDL_FreeSurface(textSurface);   textSurface=nullptr;
    return ret;
}


void Game::run()
{
    if(!initSystem())
    {
        cout<<"Error in INITIALIZING System "<<endl; cin.get(); return;
    }
    if(!loadFiles())
    {
        cout<<"Error in Loading Files "<<endl;  cin.get();  return;
    }
    gameOn=true;

    Mix_PlayMusic(bgm,-1);
    while(gameOn)
    {
        gameLoop();
    }

    for(int i=0;i<100;i++)
    {
        delete enmCars[i];
        enmCars[i]=nullptr;
    }
    Mix_HaltMusic();
    Mix_PlayChannel(-1,gameOverEffect,1);
    SDL_SetRenderDrawColor(gameRenderer,255,255,255,255);
    SDL_RenderClear(gameRenderer);
    SDL_Rect temp={0,0,SCREEN_WIDTH,400};
    SDL_RenderCopy(gameRenderer,gameOverTexture,nullptr,&temp);

    stringstream ss("");  ss<<" Your Score : "<<score<<" ";
    SDL_Color color={0,0,0,255};
    SDL_Texture *text=loadText(ss.str(),color);
    SDL_Rect scoreRect={100,400,200,100};
    SDL_RenderCopy(gameRenderer,text,nullptr,&scoreRect);

    SDL_RenderPresent(gameRenderer);

    SDL_Delay(3000);

    cleanSystem();
}

bool Game::initSystem()
{
    SDL_Init(SDL_INIT_EVERYTHING);
    IMG_Init(IMG_INIT_PNG);
    TTF_Init();
    Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048);

    gameWindow=SDL_CreateWindow("Bit my Car",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,SCREEN_WIDTH,SCREEN_HEIGHT,SDL_WINDOW_SHOWN);
    gameSurface=SDL_GetWindowSurface(gameWindow);
    gameRenderer=SDL_CreateRenderer(gameWindow,-1,SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    SDL_SetRenderDrawColor(gameRenderer,255,255,255,255);

    return true;
}

void Game::cleanSystem()
{
    SDL_FreeSurface(gameSurface);
    SDL_DestroyRenderer(gameRenderer);
    Mix_FreeChunk(gameOverEffect);
    Mix_FreeChunk(outEffect);
    Mix_FreeMusic(bgm);
    TTF_CloseFont(font);
    SDL_DestroyWindow(gameWindow);
    SDL_DestroyTexture(gameOverTexture);

    Mix_Quit();  TTF_Quit();  IMG_Quit();  SDL_Quit();
}

bool Game::loadFiles()
{
    font=TTF_OpenFont("assets/fonts/neuropol.ttf",28);
    bgm=Mix_LoadMUS("assets/music/bgm.mp3");
    gameOverEffect=Mix_LoadWAV("assets/music/gameOverEffect.wav");
    outEffect=Mix_LoadWAV("assets/music/outEffect.wav");
    gameOverTexture=loadTexture("assets/images/gameOver.png",255,255,255);
    if(!font || !ourCar.loadCar("assets/images/carSprites.png") || !background.loadBackground("assets/images/raceRoad.png")
       || !gameOverTexture || !bgm)
        return false;
    return true;
}

void Game::handleGameEvents()
{
    while(SDL_PollEvent(&gameEvents))
    {
        switch(gameEvents.type)
        {
            case SDL_QUIT :
                gameOn=false;
                break;
        }
        ourCar.handleCarEvents(gameEvents);
    }
}
void Game::updateScreen()
{
    SDL_SetRenderDrawColor(gameRenderer,255,255,255,255);
    SDL_RenderClear(gameRenderer);

    background.scrollBackground();
    background.drawBackground();


    for(int i=0;i<currentEnmCars;i++)
    {
        if(enmCars[i]==nullptr)
        {
            enmCars[i]=new EnemyCar();
        }
        else if(!enmCars[i]->updateEnemyCar())
        {
            delete enmCars[i];   enmCars[i]=nullptr;
            score+=5;
            continue;
        }
        else if(checkCollision(ourCar.carPos,enmCars[i]->destRect))
        {
            gameOn=false;  Mix_PlayChannel(-1,outEffect,0);
            SDL_Delay(2000);
            break;
        }
    }

    if(score%100==0 && score/100>0)
    {
        score+=5;// bonus
        currentEnmCars++;
        EnemyCar::maxSpeed++;
    }

    ourCar.drawCar();

    printScore();
}

void Game::renderChanges()
{
    SDL_RenderPresent(gameRenderer);
}

void Game::gameLoop()
{
    playStart=true;
    while(playStart && gameOn)
    {
        handleGameEvents();
        updateScreen();
        renderChanges();
    }
    playStart=false;
}

void Game::printScore()
{
    stringstream ss("");  ss<<" Score : "<<score<<" ";
    SDL_Color color={255,255,255,255};
    SDL_Texture *text=loadText(ss.str(),color);
    SDL_Rect scoreRect={0,0,80,40};
    SDL_SetRenderDrawColor(gameRenderer,0,0,0,255);
    SDL_RenderFillRect(gameRenderer,&scoreRect);
    SDL_RenderCopy(gameRenderer,text,nullptr,&scoreRect);
}
