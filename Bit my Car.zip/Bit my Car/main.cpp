#include "Game.h"

int main(int argc,char **argv)
{
    Game game;
    game.run();
    return 0;
}
