#ifndef ENEMYCAR_H
#define ENEMYCAR_H

#include "Game.h"


class EnemyCar
{
    public:
        EnemyCar();
        virtual ~EnemyCar();

        SDL_Rect destRect;
        int carSpeed;

        static int maxSpeed,minSpeed;
        static SDL_Texture *enemyCarTextures;


        void drawEnemyCar();
        bool updateEnemyCar();


    protected:

    private:

        SDL_Rect srcRect;

};

#endif // ENEMYCAR_H
