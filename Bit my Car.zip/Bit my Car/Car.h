#ifndef CAR_H
#define CAR_H

#define UP 1
#define LEFT 2
#define RIGHT 3
#define DOWN 4

#include "Game.h"

class Car
{
    public:
        Car();
        virtual ~Car();
        bool loadCar(std::string);

        void moveCar(int);
        void drawCar();
        void handleCarEvents(const SDL_Event& evnt);

        int xSpeed;
        int ySpeed;
        int velocity;
        SDL_Rect carPos;

    protected:

    private:

        SDL_Rect carBounds;
        SDL_Texture *carTexture;
};

#endif // CAR_H
