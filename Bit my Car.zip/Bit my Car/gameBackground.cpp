#include "gameBackground.h"

gameBackground::gameBackground()
{
    //ctor
    backgroundTexture=nullptr;

    backgroundClip={0,338,332,300};
}

gameBackground::~gameBackground()
{
    //dtor
    SDL_DestroyTexture(backgroundTexture);   backgroundTexture=nullptr;
}

bool gameBackground::loadBackground(string path)
{
    backgroundTexture=Game::loadTexture(path.c_str(),255,255,255);
    if(!backgroundTexture)  return false;
    else                    return true;
}

void gameBackground::drawBackground()
{
    SDL_RenderCopy(Game::gameRenderer,backgroundTexture,&backgroundClip,&Game::gameBoundry);
}

void gameBackground::scrollBackground()
{
    backgroundClip.y-=scrollSpeed;
    if(backgroundClip.y<=0)
        backgroundClip.y=338;
}
